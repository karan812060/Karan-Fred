$(document).ready(function(){
    $("#carousel").flipster({
            style: 'carousel',
            spacing: -0.5,
            nav: true,
            buttons:   true,
       });
    });